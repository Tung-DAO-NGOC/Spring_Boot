package tung.daongoc.question1920.repository.impl;

//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Repository;
//import tung.daongoc.question1920.model.entity.Student;
//import tung.daongoc.question1920.repository.inter.CourseStudentRepository;
//
//import javax.persistence.EntityManager;
//import java.util.List;
//import java.util.Map;
//
//@Repository
//public abstract class CourseStudentRepositoryImpl implements CourseStudentRepository {
//
//    private final String queryListStudentInClass = "SELECT * FROM ";
//
//    @Autowired
//    EntityManager em;
//
//    public Map<String, List<Student>> listStudentInClass(){
////        em.createNativeQuery("").getResultStream().collect(Collectors.toMap())
//        return null;
//    }
//}
