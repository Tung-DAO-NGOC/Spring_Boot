package tung.daongoc.question1920;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Question1920Application {

	public static void main(String[] args) {
		SpringApplication.run(Question1920Application.class, args);
	}

}
