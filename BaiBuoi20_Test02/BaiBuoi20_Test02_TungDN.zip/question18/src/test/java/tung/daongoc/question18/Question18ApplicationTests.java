package tung.daongoc.question18;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Question18ApplicationTests {

	@Test
	void contextLoads() {
	}

}
