package tung.daongoc.question18;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Question18Application {

	public static void main(String[] args) {
		SpringApplication.run(Question18Application.class, args);
	}

}
